# Devil — Creative Portfolio

A distinctive, responsive portfolio built with plain HTML, CSS and JavaScript.

## Run it

Open `index.html` directly in a browser, or use a local server:

```bash
python -m http.server 5500
```

Then visit `http://localhost:5500`.

## Customize first

1. Replace `Devil` and the email address in `index.html`.
2. Replace the three project names/descriptions.
3. Replace the CSS-generated project art with real project screenshots when ready.
4. Adjust `--accent` in `style.css` to your signature color.
5. Add your social links in the footer.
6. Connect the contact link to your real email or a form service.

## Design direction

Dark editorial / futuristic / creative-coding portfolio:
- oversized typography
- asymmetric project layouts
- lime signature accent
- custom cursor
- magnetic interactions
- subtle orbital hero animation
- experimental Lab section
- reduced-motion support
- mobile-first responsive fallback

The code deliberately avoids heavy libraries so the base site remains fast.
